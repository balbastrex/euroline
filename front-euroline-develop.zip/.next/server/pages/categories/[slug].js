(() => {
var exports = {};
exports.id = 591;
exports.ids = [591];
exports.modules = {

/***/ 2780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5976);
/* harmony import */ var styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const Spinner = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: (styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1___default().loader),
    children: "Loading..."
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Spinner);

/***/ }),

/***/ 2351:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _slug_),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/layout/Layout.js + 8 modules
var Layout = __webpack_require__(8135);
// EXTERNAL MODULE: ./context/categories/categoriesContext.js
var categories_categoriesContext = __webpack_require__(9235);
// EXTERNAL MODULE: ./components/ui/Spinner.js
var Spinner = __webpack_require__(2780);
// EXTERNAL MODULE: external "react-html-parser"
var external_react_html_parser_ = __webpack_require__(5935);
var external_react_html_parser_default = /*#__PURE__*/__webpack_require__.n(external_react_html_parser_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/categories/Categories.js




/* import Image from "next/image"; */







function Categories({
  selectedCategory,
  setPrincipalCat,
  principalCat
}) {
  const {
    0: categorySelected,
    1: setCategorySelected
  } = (0,external_react_.useState)([]);
  const categoriesContext = (0,external_react_.useContext)(categories_categoriesContext/* CategoriesContext */.i);
  const {
    categoriesSorted,
    loadSpinner,
    setLoadSpinner
  } = categoriesContext;
  const router = (0,router_.useRouter)();
  const querySlug = router.query.slug;
  (0,external_react_.useEffect)(() => {
    const getCategory = async categoriesSorted => {
      if (categorySelected) {
        setPrincipalCat(categorySelected);
      }

      return categoriesSorted.map(category => {
        if (category.id === selectedCategory.id) {
          setLoadSpinner(false);

          if (!categorySelected.includes(category)) {
            setCategorySelected([category]);
          }
        } else if (category.subCategory.length) {
          getCategory(category.subCategory);
        }
      });
    };

    getCategory(categoriesSorted); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoriesSorted, categorySelected, selectedCategory.id]);

  const handleSpinnerLoad = elementSelected => {
    if (elementSelected === categorySelected[0]) {
      setLoadSpinner(false);
      return elementSelected;
    } else if (elementSelected !== categorySelected[0]) {
      setLoadSpinner(true);
    }
  };

  let loopCount = 0;

  const categoriesGroup = categorySelected => {
    return categorySelected.map(selectedCategory => {
      loopCount++;
      return /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_.Fragment, {
        children: [selectedCategory.slug === querySlug ? null : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "subcategoria",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: {
              pathname: "/[slug]",
              query: {
                slug: selectedCategory.slug
              }
            },
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                  src: selectedCategory.main_image === null ? "/mi_pipo.jpg" : `${"https://ecomm.skydone.net"}${selectedCategory.main_image.src}`,
                  type: "image/webp"
                }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: selectedCategory.main_image === null ? "/mi_pipo.jpg" : `${"https://ecomm.skydone.net"}${selectedCategory.main_image.src}`,
                  alt: selectedCategory.main_image && selectedCategory.main_image.alt !== "" ? selectedCategory.main_image.alt : `${selectedCategory.name} image`
                })]
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
              href: {
                pathname: "/[slug]",
                query: {
                  slug: selectedCategory.slug
                }
              },
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: "nombre",
                onClick: () => handleSpinnerLoad(selectedCategory),
                children: selectedCategory.name
              })
            })
          })]
        }, selectedCategory.id), selectedCategory.subCategory.length && loopCount === 1 ? categoriesGroup(selectedCategory.subCategory) : null]
      }, selectedCategory.id);
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: !loadSpinner ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "container cabecera categoria bkg",
          children: principalCat[0] && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                src: selectedCategory.main_image === null ? "/mi_pipo.jpg" : `${"https://ecomm.skydone.net"}${selectedCategory.main_image.src}`,
                type: "image/webp"
              }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                src: principalCat[0].main_image === null || principalCat[0].main_image === undefined ? "/mi_pipo.jpg" : `${"https://ecomm.skydone.net"}${principalCat[0].main_image.src}`,
                alt: principalCat[0].main_image && principalCat[0].main_image.alt !== "" ? principalCat[0].main_image.alt : `${principalCat[0].name} image`
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "cartel",
              children: [/*#__PURE__*/jsx_runtime_.jsx("h5", {
                children: principalCat[0].name
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                children: external_react_html_parser_default()(principalCat[0].html)
              })]
            })]
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("section", {
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          id: "listado-subcategorias",
          className: "container",
          children: categoriesGroup(categorySelected)
        })
      })]
    }) : /*#__PURE__*/jsx_runtime_.jsx(Spinner/* default */.Z, {})
  });
}

/* harmony default export */ const categories_Categories = (Categories);
// EXTERNAL MODULE: ./api/apiRoutes.js
var apiRoutes = __webpack_require__(3631);
// EXTERNAL MODULE: ./context/designs/designsContext.js
var designs_designsContext = __webpack_require__(4092);
// EXTERNAL MODULE: ./components/ui/DesignCard.js
var DesignCard = __webpack_require__(7468);
;// CONCATENATED MODULE: ./components/designs/DesignsGroup.js








function DesignsGroup({
  selectedCategory,
  prodByCategory,
  principalCat,
  productsByTag,
  packByCategory
}) {
  const categoriesContext = (0,external_react_.useContext)(categories_categoriesContext/* CategoriesContext */.i);
  const {
    loadSpinner
  } = categoriesContext;
  const designsContext = (0,external_react_.useContext)(designs_designsContext/* DesignsContext */.y);
  const {
    allDesigns,
    stopGetDesigns,
    productByCategory,
    setStopGetDesigns,
    getDesigns
  } = designsContext;
  let prodName; //  NOTE: El precio que aparece en cada Card lo cogemos de la variación (product.variation.price)

  if (productByCategory && productByCategory.length) {
    productByCategory.map(product => {
      prodName = product.name;
      allDesigns.map(design => {
        if (product.shop_design_group_id === design.shop_design_group_id) {
          design.price = product.variation.price;
        }
      });
    });
  }

  (0,external_react_.useEffect)(() => {
    if (!stopGetDesigns) {
      getDesigns(prodByCategory);
    }

    setStopGetDesigns(false); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCategory.id, productByCategory]);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: !loadSpinner ? /*#__PURE__*/jsx_runtime_.jsx("section", {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        id: "listado-productos",
        className: "container",
        children: principalCat[0] && principalCat[0].subCategory.length === 0 && productByCategory && !productsByTag ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: allDesigns.map(design => {
            return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
              children: (0,DesignCard/* DesignCard */.F)(design)
            }, design.id);
          })
        }) : productsByTag || packByCategory ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [productsByTag && productsByTag.map(prodTag => {
            if (!prodTag.products) return;
            return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
              children: (0,DesignCard/* DesignCard */.F)(prodTag)
            }, prodTag.id);
          }), packByCategory && packByCategory.map(packCat => {
            return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
              children: (0,DesignCard/* DesignCard */.F)(packCat)
            }, packCat.id);
          })]
        }) : null
      })
    }) : null
  });
}

/* harmony default export */ const designs_DesignsGroup = (DesignsGroup);
;// CONCATENATED MODULE: ./pages/categories/[slug].js





/* import DesignsGroup from "components/designs/DesignsGroup"; */








function CategoriesGroup({
  sortedCategory,
  prodByCategory,
  productsByTag,
  packByCategory
}) {
  const categoriesContext = (0,external_react_.useContext)(categories_categoriesContext/* CategoriesContext */.i);
  const {
    selectedCategory,
    setSelectedCategory
  } = categoriesContext;
  const {
    0: principalCat,
    1: setPrincipalCat
  } = (0,external_react_.useState)([]); //NOTE: Adding sortedCategory to context and send it to Categories and saving category selected in localstorage

  (0,external_react_.useEffect)(() => {
    const AddCategoryContext = () => {
      setSelectedCategory(sortedCategory);
    };

    AddCategoryContext();
  }, [sortedCategory, selectedCategory, setSelectedCategory]);
  const router = (0,router_.useRouter)();

  if (router.isFallback) {
    return /*#__PURE__*/jsx_runtime_.jsx(Layout/* default */.Z, {
      page: "Categorias",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/jsx_runtime_.jsx(Spinner/* default */.Z, {})
      })
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(Layout/* default */.Z, {
    page: selectedCategory.name,
    name: "description",
    content: selectedCategory.description,
    children: [/*#__PURE__*/jsx_runtime_.jsx(categories_Categories, {
      selectedCategory: selectedCategory,
      principalCat: principalCat,
      setPrincipalCat: setPrincipalCat,
      productsByTag: productsByTag
    }), /*#__PURE__*/jsx_runtime_.jsx(designs_DesignsGroup, {
      selectedCategory: selectedCategory,
      prodByCategory: prodByCategory,
      principalCat: principalCat,
      productsByTag: productsByTag,
      packByCategory: packByCategory
    })]
  });
}

async function getStaticPaths() {
  const AllCategories = await (0,apiRoutes/* getAllCategories */.tG)();
  const paths = await AllCategories.map(category => ({
    params: {
      slug: category.slug || "404"
    }
  }));
  return {
    paths,
    fallback: true
  };
}
async function getStaticProps({
  params: {
    slug
  }
}) {
  let sortedCategory;
  let categoryId;
  let tagId;
  let productsByTag;

  try {
    const AllCategories = await (0,apiRoutes/* getAllCategories */.tG)();
    AllCategories.map(category => {
      if (category.slug === slug) {
        sortedCategory = category;
        categoryId = category.id;

        if (category.tag !== null) {
          tagId = category.tag.id;
        }
      }
    });
  } catch (error) {
    console.log(error);
  }

  const prodByCategory = await (0,apiRoutes/* getProductsByCategory */.V8)(categoryId);
  const packByCategory = await (0,apiRoutes/* getPackByCategory */.Uz)(categoryId);

  if (prodByCategory) {
    productsByTag = await (0,apiRoutes/* getDesignByTag */.ed)(tagId);
  }

  return {
    props: {
      sortedCategory: sortedCategory || null,
      prodByCategory: prodByCategory || null,
      productsByTag: productsByTag || null,
      packByCategory: packByCategory || null
    },
    revalidate: 10
  };
}
/* harmony default export */ const _slug_ = (CategoriesGroup);

/***/ }),

/***/ 5976:
/***/ ((module) => {

// Exports
module.exports = {
	"loader": "Spinner_loader__U4LJD",
	"load5": "Spinner_load5__s2jZt"
};


/***/ }),

/***/ 3013:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/base");

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 5935:
/***/ ((module) => {

"use strict";
module.exports = require("react-html-parser");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [400,664,631,274,135,468,92], () => (__webpack_exec__(2351)));
module.exports = __webpack_exports__;

})();