"use strict";
(() => {
var exports = {};
exports.id = 905;
exports.ids = [905];
exports.modules = {

/***/ 8745:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8135);
/* harmony import */ var _api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3631);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_ui_Spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2780);
/* harmony import */ var components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4824);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_5__]);
components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function DesignDetail({
  selectedProduct,
  designSelected,
  addCart
}) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
  let metaContent;
  let metaPage;

  if (router.isFallback) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      page: "Dise\xF1os",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_ui_Spinner__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
      })
    });
  }

  {
    designSelected && designSelected.meta_title ? metaPage = designSelected.meta_title : !designSelected || !designSelected.meta_title ? metaPage = `${selectedProduct.name} ${designSelected.name}` : null;
  }
  {
    designSelected && designSelected.meta_description ? metaContent = designSelected.meta_description : !designSelected || !designSelected.meta_description ? metaContent = designSelected.description || designSelected.name : null;
  }
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    page: metaPage,
    name: "description",
    content: metaContent,
    children: selectedProduct || designSelected ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
      selectedProduct: selectedProduct,
      designSelected: designSelected,
      addCart: addCart
    }) : null
  });
}

async function getStaticPaths() {
  let allDesignsGroupCopy;
  let allDesigns;
  let data = [];
  let productSlug;
  const Allproducts = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getAllProducts */ .Dg)();

  if (Allproducts) {
    for (let i = 0; i < Allproducts.length; i++) {
      try {
        if (Allproducts[i].shop_design_group_id !== null) {
          const designId = await Allproducts[i].shop_design_group_id;
          const allDesignGroupById = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getDesignGroupsById */ .kN)(designId);
          allDesignsGroupCopy = await allDesignGroupById;
          productSlug = await Allproducts[i].slug; //NOTE: filtrar los repetidos y meterlos en data

          if (allDesignGroupById !== undefined) {
            allDesignGroupById.map(design => {
              design.productSlug = productSlug || "";
              allDesigns = allDesignsGroupCopy.filter(designCopy => {
                design.id === designCopy.id && !data.includes(designCopy);
              });
            });
          }
        }
      } catch (error) {
        console.log("Hubo un error", error);
      }
    }
  }

  if (allDesigns) {
    const paths = allDesigns.map(design => ({
      params: {
        designDetail: design.slug || null,
        productDetail: !design.canonical_uri && design.productSlug || null
      }
    }));
    return {
      paths,
      fallback: true
    };
  } else {
    return {
      paths: [],
      fallback: true
    };
  }
}
async function getStaticProps({
  params
}) {
  let allProducts;
  let selectedProduct;
  let designSelected;
  let productId;

  try {
    allProducts = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getAllProducts */ .Dg)();
    await allProducts.map(prod => {
      if (prod.slug === params.productDetail) {
        productId = prod.id;
      }
    });
    selectedProduct = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getProduct */ .wv)(productId);
    const groupId = await selectedProduct.shop_design_group_id;
    const designs = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getDesignGroupsById */ .kN)(groupId);
    await designs.map(design => {
      if (design.slug === params.designDetail) {
        return designSelected = design;
      }
    });
  } catch (error) {
    console.log(error);
  }

  return {
    props: {
      selectedProduct: selectedProduct || null,
      designSelected: designSelected || null
    },
    revalidate: 10
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DesignDetail);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3013:
/***/ ((module) => {

module.exports = require("@mui/base");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5935:
/***/ ((module) => {

module.exports = require("react-html-parser");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [400,664,631,274,135,641], () => (__webpack_exec__(8745)));
module.exports = __webpack_exports__;

})();