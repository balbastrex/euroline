"use strict";
(() => {
var exports = {};
exports.id = 689;
exports.ids = [689];
exports.modules = {

/***/ 2930:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8135);
/* harmony import */ var _api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3631);
/* harmony import */ var components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4824);
/* harmony import */ var components_ui_Spinner__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2780);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_3__]);
components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function ShopPoducts({
  productDetail,
  packDetail,
  addCart
}) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
  let metaPage;
  let metaContent;

  if (router.isFallback) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
      page: "Art\xEDculos",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_ui_Spinner__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
      })
    });
  }

  {
    productDetail ? productDetail.meta_title !== null ? metaPage = productDetail.meta_title : productDetail.meta_title === null ? metaPage = productDetail.name : null : packDetail ? packDetail.meta_title !== null ? metaPage = packDetail.meta_title : packDetail.meta_title === null ? metaPage = packDetail.name : null : null;
  }
  {
    productDetail ? productDetail.meta_description !== null ? metaContent = productDetail.meta_description : productDetail.meta_description === null ? metaContent = productDetail.description : null : packDetail ? packDetail.meta_description !== null ? metaContent = packDetail.meta_description : packDetail.meta_description === null ? metaContent = packDetail.description : null : null;
  }
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
    page: metaPage,
    name: "description",
    content: metaContent,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(components_detailPages_CardDetail__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
      productDetail: productDetail,
      packDetail: packDetail,
      addCart: addCart
    })
  });
}

async function getStaticPaths() {
  let canonical = [];
  const products = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getAllProducts */ .Dg)();
  const packs = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getPacks */ .KQ)();
  {
    products ? canonical = [...canonical, ...products] : packs ? canonical = [...canonical, ...packs] : canonical;
  }
  const paths = canonical.map(product => ({
    params: {
      productDetail: product.canonical_uri.replace(/[/]/g, "_")
    }
  }));
  return {
    paths,
    fallback: true
  };
}
async function getStaticProps({
  params
}) {
  let productDetail;
  let packDetail;
  let productId;
  let packId;
  let productByCategoryPre = [];

  try {
    const products = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getAllProducts */ .Dg)();
    const packs = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getPacks */ .KQ)();

    if (products) {
      productByCategoryPre = [...productByCategoryPre, ...products];
    }

    if (packs) {
      productByCategoryPre = [...productByCategoryPre, ...packs];
    }

    productByCategoryPre.map(product => {
      if (product.canonical_uri.replace(/[/]/g, "_") === params.productDetail) {
        if (product.ref) {
          packId = product.id;
        } else {
          productId = product.id;
        }
      }
    });
  } catch (error) {
    console.log(error);
  }

  if (productId) {
    productDetail = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getProduct */ .wv)(productId);
  }

  if (packId) {
    packDetail = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getPackById */ .ko)(packId);
  }

  return {
    props: {
      productDetail: productDetail || null,
      packDetail: packDetail || null
    },
    revalidate: 10
  };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShopPoducts);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3013:
/***/ ((module) => {

module.exports = require("@mui/base");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5935:
/***/ ((module) => {

module.exports = require("react-html-parser");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3590:
/***/ ((module) => {

module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [400,664,631,274,135,641], () => (__webpack_exec__(2930)));
module.exports = __webpack_exports__;

})();