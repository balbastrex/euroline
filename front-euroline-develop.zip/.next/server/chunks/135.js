"use strict";
exports.id = 135;
exports.ids = [135];
exports.modules = {

/***/ 8135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout_Layout)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./context/categories/categoriesContext.js
var categories_categoriesContext = __webpack_require__(9235);
// EXTERNAL MODULE: ./api/apiRoutes.js
var apiRoutes = __webpack_require__(3631);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "@mui/base"
var base_ = __webpack_require__(3013);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/menu/MenuList.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const MenuList = ({
  hideMenu,
  setHideMenu
}) => {
  const router = (0,router_.useRouter)();
  const categoriesContext = (0,external_react_.useContext)(categories_categoriesContext/* CategoriesContext */.i);
  const {
    categoriesSorted,
    setLoadSpinner
  } = categoriesContext;

  const handleLink = category => {
    setHideMenu(false);

    if (category.slug === router.query.slug) {
      setLoadSpinner(false);
    } else {
      setLoadSpinner(true);
    }
  };

  const Child = sortedCategory => {
    return /*#__PURE__*/jsx_runtime_.jsx("li", {
      children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: {
          pathname: "/categories/[slug]",
          query: {
            slug: sortedCategory.slug
          }
        },
        as: `/${sortedCategory.slug}`,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          onClick: () => handleLink(sortedCategory),
          children: sortedCategory.name
        })
      })
    });
  };

  const Parent = sortedCategory => {
    const {
      0: liClass,
      1: setLiClass
    } = (0,external_react_.useState)("submenu-hidden");
    const subCategory = sortedCategory.subCategory;
    return /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
      className: liClass,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: {
            pathname: "/categories/[slug]",
            query: {
              slug: sortedCategory.slug
            }
          },
          as: `/${sortedCategory.slug}`,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            onClick: () => handleLink(sortedCategory),
            children: sortedCategory.name
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "icon",
          onClick: () => liClass == "submenu-hidden" ? setLiClass("submenu") : setLiClass("submenu-hidden"),
          children: "keyboard_arrow_down"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
        children: CreateList(subCategory)
      })]
    });
  };

  const CreateList = categoriesSorted => {
    return categoriesSorted.map(sortedCategory => {
      return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: sortedCategory.subCategory.length ? /*#__PURE__*/jsx_runtime_.jsx(Parent, _objectSpread({}, sortedCategory)) : /*#__PURE__*/jsx_runtime_.jsx(Child, _objectSpread({}, sortedCategory))
      });
    });
  };

  return /*#__PURE__*/jsx_runtime_.jsx(base_.ClickAwayListener, {
    onClickAway: () => setHideMenu(false),
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "menu",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "close icon",
        onClick: () => setHideMenu(!hideMenu),
        children: "close"
      }), hideMenu ? /*#__PURE__*/jsx_runtime_.jsx("ul", {
        children: CreateList(categoriesSorted)
      }) : null]
    })
  });
};

/* harmony default export */ const menu_MenuList = (MenuList);
// EXTERNAL MODULE: ./context/cart/cartContext.js
var cart_cartContext = __webpack_require__(491);
// EXTERNAL MODULE: ./context/user/userContext.js
var userContext = __webpack_require__(8753);
// EXTERNAL MODULE: ./components/auth/authHelpers.js
var authHelpers = __webpack_require__(7504);
;// CONCATENATED MODULE: ./components/searchBar/ResultBox.js





function ResultBox(params) {
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: "#",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/jsx_runtime_.jsx("picture", {
          children: /*#__PURE__*/jsx_runtime_.jsx("img", {
            src: "https://picsum.photos/200",
            type: "image/webp",
            alt: ""
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
          children: params.name
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: "650\u20AC"
        })]
      })]
    })
  });
}

/* harmony default export */ const searchBar_ResultBox = (ResultBox);
;// CONCATENATED MODULE: ./components/searchBar/SearchComponent.js



 // const handleDragStart = (e) => e.preventDefault();




const SearchBar = () => {
  const {
    0: ref,
    1: setRef
  } = (0,external_react_.useState)("");
  const {
    0: results,
    1: setResults
  } = (0,external_react_.useState)([]);
  const {
    0: message,
    1: setMessage
  } = (0,external_react_.useState)("");
  const {
    0: showClass,
    1: setShowClass
  } = (0,external_react_.useState)(false);

  const finder = async ref => {
    if (ref.length > 2) {
      const response = await (0,apiRoutes/* getSearchProductByString */.ps)(ref);
      const success = response.data.success;
      setMessage(response.data.message);

      if (success == true) {
        setResults(response.data.data.variations);
      } else if (success == false) {
        setResults([]);
      }
    } else if (ref.length < 1) {
      setResults([]);
      setMessage("");
    }
  };

  const handleSearchValue = async e => {
    e.preventDefault();
    const value = e.target.value;
    setRef(value);
    finder(value);
  };

  const clearData = () => {
    setRef("");
    setResults("");
    setMessage("");
  };

  return /*#__PURE__*/jsx_runtime_.jsx(base_.ClickAwayListener, {
    onClickAway: () => {
      setShowClass(false);
      clearData();
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "search-component",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
        className: "buscador",
        onClick: () => {
          setShowClass(!showClass);
          clearData();
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "icon",
          children: "search"
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: "Buscar"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: showClass ? "search-box" : "search-box-hidden",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "input-box",
          children: /*#__PURE__*/jsx_runtime_.jsx("input", {
            type: "search",
            className: "search-input",
            placeholder: "Escribe para buscar...",
            value: ref,
            onChange: e => handleSearchValue(e)
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "results-box",
          children: /*#__PURE__*/jsx_runtime_.jsx("ul", {
            className: "results-list",
            children: results.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
              children: results.map(item => /*#__PURE__*/jsx_runtime_.jsx(searchBar_ResultBox, {
                name: item.name
              }, item.key))
            }) : /*#__PURE__*/jsx_runtime_.jsx("p", {
              children: message
            })
          })
        })]
      })]
    })
  });
};

/* harmony default export */ const SearchComponent = (SearchBar);
;// CONCATENATED MODULE: ./components/layout/Header.js













const Header = ({
  hideMenu,
  setHideMenu
}) => {
  const categoriesContext = (0,external_react_.useContext)(categories_categoriesContext/* CategoriesContext */.i);
  const {
    categories,
    categoriesSorted,
    getCategoriesSorted
  } = categoriesContext;
  const {
    tokenstored,
    setTokenStored
  } = (0,external_react_.useContext)(userContext/* UserContext */.S);
  const cartContext = (0,external_react_.useContext)(cart_cartContext/* CartContext */.A);
  const {
    cart,
    setCart,
    tokenCart
  } = cartContext;
  (0,external_react_.useEffect)(() => {
    if (categoriesSorted.length === 0 && categories[0]) {
      getCategoriesSorted();
    }
  }, [categories, categoriesSorted.length, getCategoriesSorted]);
  (0,external_react_.useEffect)(() => {
    const checkTokenSession = async () => {
      (0,authHelpers/* getTokenSession */.BV)();

      if (!(0,authHelpers/* getTokenSession */.BV)()) {
        setTokenStored(false);
        console.log("Not authorized");
        return;
      }

      setTokenStored(true);
    };

    checkTokenSession();
  }, [tokenstored]); //Cargamos carro.

  (0,external_react_.useEffect)(() => {
    const getCart = async () => {
      /* Si hay tokenCart, cargamos carro público */
      if (tokenCart) {
        const publicCart = await (0,apiRoutes/* getPublicCart */.gv)(tokenCart);

        if (publicCart) {
          setCart(publicCart.cart);
        }

        return;
      }
      /* Si no, cargamos carro privado */


      if (tokenstored) {
        const customerCart = await (0,apiRoutes/* getCustomerCart */.VQ)();

        if (customerCart) {
          setCart(customerCart.cart);
        }

        return;
      }
    };

    getCart();
  }, [setCart, tokenCart, tokenstored]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("header", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      id: "top-header",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container"
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      id: "header",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "burger icon",
          onClick: () => setHideMenu(!hideMenu),
          children: "menu"
        }), hideMenu ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
          children: /*#__PURE__*/jsx_runtime_.jsx(menu_MenuList, {
            hideMenu: hideMenu,
            setHideMenu: setHideMenu
          })
        }) : null, /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "logo",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/",
            passHref: true,
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("picture", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("source", {
                  src: "/logo_convert_cars.jpg",
                  type: "image/webp"
                }), /*#__PURE__*/jsx_runtime_.jsx("img", {
                  src: "/logo_convert_cars.jpg",
                  alt: "convert-cars-logo"
                })]
              })
            })
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "botones",
          children: [/*#__PURE__*/jsx_runtime_.jsx(SearchComponent, {}), tokenstored ? /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/profile",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "sesion",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "icon",
                children: "person"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: "Mi Cuenta"
              })]
            })
          }) : /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/auth/register",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "sesion",
              children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                className: "icon",
                children: "person"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: "Iniciar sesi\xF3n"
              })]
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
            href: "/cart",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "carrito",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "icon",
                children: ["shopping_cart", cart && cart.lines && cart.lines.length >= 1 ? /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "contador",
                  children: cart.lines.length
                }) : /*#__PURE__*/jsx_runtime_.jsx("p", {
                  className: "contador",
                  children: "0"
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: "Carrito"
              })]
            })
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      id: "aviso-header",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "teleprompter",
          children: "Chanante ipsum dolor sit amet, tontiploster, freshquisimo ad atiendee zagal hueles avinagrado ju-j\xE1 chotera et. Veniam tempor sed estoy fatal de lo m\xEDo agazapao. Horcate incididunt, veniam cosica exercitation droja bizcoch\xE9 elit coconut ad dolore, traeros tol jam\xF3n interneeeer ga\xF1\xE1n."
        })
      })
    })]
  });
};

/* harmony default export */ const layout_Header = (Header);
;// CONCATENATED MODULE: ./components/topMenu/TopMenuCard.js




function TopMenuCard(params) {
  const slug = params.category.slug;
  const name = params.category.name;
  const src = params.src;
  return /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: {
      pathname: "/categories/[slug]",
      query: {
        slug: slug
      }
    },
    as: `/categories/${slug}`,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
      className: "hover",
      children: [/*#__PURE__*/jsx_runtime_.jsx("picture", {
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: `${"https://ecomm.skydone.net"}` + src,
          alt: "logo"
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("p", {
        children: name
      })]
    })
  });
}
;// CONCATENATED MODULE: ./components/layout/TopMenu.js
function TopMenu_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function TopMenu_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { TopMenu_ownKeys(Object(source), true).forEach(function (key) { TopMenu_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { TopMenu_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function TopMenu_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const TopMenu = () => {
  const {
    0: topCategories,
    1: setTopCategories
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    const getTop = async () => {
      const topCategoriesResponse = await (0,apiRoutes/* getTopCategories */.cd)();
      setTopCategories(topCategoriesResponse);
    };

    getTop();
  }, []);
  const items = topCategories;
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("section", {
      id: "top-menu",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container",
        children: items.map((item, key) => /*#__PURE__*/jsx_runtime_.jsx(TopMenuCard, TopMenu_objectSpread({}, item), key))
      }), /*#__PURE__*/jsx_runtime_.jsx("hr", {})]
    })
  });
};

/* harmony default export */ const layout_TopMenu = (TopMenu);
;// CONCATENATED MODULE: ./components/layout/Footer.js



const Footer = () => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      id: "top-footer",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container",
        children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
          children: "www.convertcars.net"
        })
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      id: "footer",
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
            children: "CONVERT CARS"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Qui\xE9nes somos"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Cat\xE1logo pdf"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Anexo pdf"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Noticias"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Contacto"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Descargas"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
            children: "COMPRAR"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "C\xF3mo comprar"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Profesionales"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Particulares"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Condiciones de compra"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Productos agotados temporalmente"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
            children: "LEGAL"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Condiciones de uso"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Aviso Legal"
          }), /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "#",
            children: "Pol\xEDtica de Privacidad"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "boletin",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h6", {
            children: "Bolet\xEDn de noticias Convert Cars"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
            id: "boletin",
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "mail",
              placeholder: "Escribe tu email"
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {}), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "checkbox"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: "privacidad",
              children: ["Acepto la ", /*#__PURE__*/jsx_runtime_.jsx("a", {
                href: "#",
                children: "pol\xEDtica de privacidad"
              }), "."]
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "submit",
              value: "Suscribirme"
            })]
          })]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      id: "copyright",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "container",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          children: ["\xA9 EUROLINE - ", new Date().getFullYear(), ". EUROLINE", /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "simbolo",
            children: "\xAE"
          }), " es una marca registrada."]
        })
      })
    })]
  });
};

/* harmony default export */ const layout_Footer = (Footer);
;// CONCATENATED MODULE: ./components/ui/Breadcrumbs.js






const convertBreadcrumb = string => {
  return string.replace(/[/]/g, "_").replace(/-/g, " ").replace(/_/g, "").replace(/ö/g, "oe").replace(/ä/g, "ae").replace(/ü/g, "ue").toUpperCase();
};

const Breadcrumbs = () => {
  const router = (0,router_.useRouter)();
  const {
    0: breadcrumbs,
    1: setBreadcrumbs
  } = (0,external_react_.useState)(null);
  (0,external_react_.useEffect)(() => {
    if (router) {
      const linkPath = router.asPath.split("/");
      linkPath.shift();
      const pathArray = linkPath.map((path, i) => {
        return {
          breadcrumb: path,
          href: "/" + linkPath.slice(0, i + 1).join("/")
        };
      });
      setBreadcrumbs(pathArray);
    }
  }, [router]);

  if (!breadcrumbs) {
    return null;
  }

  const splitBreadcrumb = breadcrumb => {};

  const printBreadcrumb = breadcrumb => {
    return breadcrumb.breadcrumb != "shop" ? /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
      href: breadcrumb.href,
      children: /*#__PURE__*/jsx_runtime_.jsx("a", {
        children: convertBreadcrumb(breadcrumb.breadcrumb)
      })
    }, breadcrumb.href) : null;
  };

  return /*#__PURE__*/jsx_runtime_.jsx("section", {
    id: "breadcrumbs",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "container breadcrumbs",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: "/",
        passHref: true,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: "HOME"
        })
      }), breadcrumbs.map(breadcrumb => {
        return breadcrumb.breadcrumb.includes("/") ? splitBreadcrumb(breadcrumb) : /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: breadcrumb.href,
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: convertBreadcrumb(breadcrumb.breadcrumb)
          })
        }, breadcrumb.href);
      })]
    })
  });
};

/* harmony default export */ const ui_Breadcrumbs = (Breadcrumbs);
;// CONCATENATED MODULE: ./components/layout/Layout.js











const Layout = ({
  children,
  page,
  content,
  name
}) => {
  const categoriesContext = (0,external_react_.useContext)(categories_categoriesContext/* CategoriesContext */.i);
  const {
    setCategories
  } = categoriesContext;
  const {
    0: hideMenu,
    1: setHideMenu
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    const nuevoUpdate = async () => {
      const allCategories = await (0,apiRoutes/* getAllCategories */.tG)();
      await setCategories(allCategories);
    };

    nuevoUpdate();
  }, [setCategories]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("title", {
        children: ["Convert Cars - ", page]
      }), /*#__PURE__*/jsx_runtime_.jsx("link", {
        rel: "shortcut icon",
        href: "/convert_cars.png"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: name,
        content: content
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "keywords",
        content: "Paragolpes, Faros Luz Diurna, Alerones, Pilotos"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(layout_Header, {
      setHideMenu: setHideMenu,
      hideMenu: hideMenu
    }), /*#__PURE__*/jsx_runtime_.jsx(layout_TopMenu, {
      setHideMenu: setHideMenu,
      hideMenu: hideMenu
    }), /*#__PURE__*/jsx_runtime_.jsx(ui_Breadcrumbs, {}), children, /*#__PURE__*/jsx_runtime_.jsx(layout_Footer, {})]
  });
};

/* harmony default export */ const layout_Layout = (Layout);

/***/ })

};
;