exports.id = 646;
exports.ids = [646];
exports.modules = {

/***/ 1591:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var context_user_userContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8753);
/* harmony import */ var context_cart_cartContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(491);
/* harmony import */ var api_apiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3631);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _authHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7504);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_6__]);
react_toastify__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }














const UserRegister = () => {
  const {
    user,
    login,
    setUser,
    setLogin,
    initialUser,
    initialLogin,
    setTokenSession,
    tokensession,
    tokenstored,
    setTokenStored
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context_user_userContext__WEBPACK_IMPORTED_MODULE_1__/* .UserContext */ .S);
  const cartContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context_cart_cartContext__WEBPACK_IMPORTED_MODULE_2__/* .CartContext */ .A);
  const {
    cart,
    setCart,
    addCart,
    tokenCart,
    setTokenCart
  } = cartContext;
  const {
    0: invalidpassword,
    1: setInvalidPassword
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: open,
    1: setOpen
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: emailfound,
    1: setEmailfound
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: loginerror,
    1: setLoginError
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: loginok,
    1: setLoginOk
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: carttoken,
    1: setCartToken
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)(); //Comprobamos si hay token de carro en localStorage y si lo hay lo almacenamos en carttoken

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const loadUser = async () => {
      const loggedUserJSON = window.localStorage.getItem("tokenSessionStorageClient");
      const anonimousCartToken = await (0,_authHelpers__WEBPACK_IMPORTED_MODULE_8__/* .getStoredAnonymousCartToken */ .Xv)();

      if (anonimousCartToken) {
        setCartToken(anonimousCartToken);
      }

      if (!loggedUserJSON) {
        return;
      }

      try {
        setTokenStored(true);
      } catch (error) {
        console.log(error);
      }
    };

    loadUser();
  }, []);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const getCartToken = async () => {
      const localCartToken = await (0,_authHelpers__WEBPACK_IMPORTED_MODULE_8__/* .getStoredAnonymousCartToken */ .Xv)();

      if (localCartToken) {
        initialLogin.token = localCartToken;
      }
    };

    getCartToken();
  }, [initialLogin]);

  const handleChangeRegister = e => {
    setUser(_objectSpread(_objectSpread({}, user), {}, {
      [e.target.name]: e.target.value
    }));
  };

  const handleChangeLogin = e => {
    setLogin(_objectSpread(_objectSpread({}, login), {}, {
      [e.target.name]: e.target.value,
      token: carttoken
    }));
  };

  const handleRadio = async e => {
    const checked = e.target.checked;
    const checkboxvalue = e.target.value;
    const checkname = e.target.name;

    for (let i in user) {
      if (checked && i === checkname && !user[i].includes(checkboxvalue)) {
        user[i].push(checkboxvalue);
      } else if (!checked && i === checkname) {
        let filterCheckBox = user[i].filter(value => value !== checkboxvalue);
        return user[i] = filterCheckBox;
      }
    }
  };

  const handleCheck = e => {
    setUser(_objectSpread(_objectSpread({}, user), {}, {
      [e.target.name]: e.target.checked
    }));
  };

  const handleSesion = estado => {
    if (open !== estado) {
      setOpen(estado);
    }
  };

  const handleSubmitRegister = async (registerEmail, e) => {
    e.preventDefault(); //Validamos que no haya ningún campo vacío

    if (user.name.trim() !== "" || user.email.trim() !== "" || user.password.trim() !== "" || user.password2.trim() !== "") {
      //Validamos que las contraseñas sean iguales
      if (user.password !== user.password2) {
        setInvalidPassword(true);
        return;
      } //Validación del correo


      const emailChecked = await (0,api_apiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .confirmRegisterEmail */ .vS)(registerEmail);

      if (emailChecked === "Email encontrad@") {
        setEmailfound(true);
        return;
      }

      setLoginOk(true); //Mensage Toast de registro correcto

      react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.success("👌¡Registrad@ correctamente!", {
        position: "top-center",
        autoClose: 2500,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        className: "toast"
      });
      setTimeout(() => {
        setLoginOk(false);
        setEmailfound(false);
        setInvalidPassword(false);
        setUser(initialUser);
        (0,api_apiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .userRegister */ .N$)(user);
        handleSesion(false);
        /* e.target.reset() */
      }, 3000);
    }
  }; //Logueamos


  const handleSubmitLogin = async (login, e) => {
    e.preventDefault(); //Enviamos los datos de login para recibir el token

    const loginResponse = await (0,api_apiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .authLogin */ .eU)(login);
    console.log(loginResponse); //Almacenamos el token en el localStorage con el nombre de "tokensession"

    if (!loginResponse) {
      setLogin(initialLogin);
      setTimeout(() => {
        setLoginError(false);
      }, 3000);
      setLoginError(true);
      /* handleSesion(true); */
    } else {
      window.localStorage.setItem("tokenSessionStorageClient", loginResponse.token.access_token);
      setTokenStored(true);
      (0,_authHelpers__WEBPACK_IMPORTED_MODULE_8__/* .detelteCartToken */ .uC)();
      setCart(() => loginResponse.cart);
      setTokenCart("");
      setLogin(initialLogin);
      router.push("/");
    }

    setLogin(initialLogin);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("section", {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        id: "inicio-registro",
        className: "container",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "tit",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
            id: "sesion",
            name: "sesion",
            type: "radio",
            readOnly: true,
            checked: !open ? true : false,
            value: open,
            onClick: () => handleSesion(false)
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
            children: "INICIA SESI\xD3N"
          })]
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "tit",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
            id: "registro",
            name: "registro",
            type: "radio",
            readOnly: true,
            checked: open ? true : false,
            value: open,
            onClick: () => handleSesion(true)
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
            children: "REG\xCDSTRATE"
          })]
        }), loginok && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
          className: "formularios",
          style: {
            height: "auto"
          },
          children: !open ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
              className: "sesion open",
              onSubmit: e => handleSubmitLogin(login, e),
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
                children: "Email"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
                onChange: e => handleChangeLogin(e),
                id: "email",
                type: "email",
                name: "email",
                value: login.email,
                required: true
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
                children: "Contrase\xF1a"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
                id: "pass",
                type: "password",
                name: "password",
                value: login.password,
                onChange: e => handleChangeLogin(e),
                autoComplete: "on",
                required: true
              }), loginerror && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
                className: "error-validacion",
                children: "Su email o contrase\xF1a no coinciden. Int\xE9ntelo de nuevo"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
                className: "recordar",
                type: "checkbox"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
                children: "Recordar contrase\xF1a"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
                type: "submit",
                value: "Enviar"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
                href: "#",
                className: "olvidado",
                children: "\xBFHas olvidado tu contrase\xF1a?"
              })]
            })
          }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
            className: "registro open",
            onSubmit: e => handleSubmitRegister(user.email, e),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h6", {
              children: "Soy particular"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Nombre"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              id: "text",
              name: "name",
              type: "text",
              value: user.name,
              required: true,
              onChange: e => handleChangeRegister(e)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Email"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              id: "email",
              name: "email",
              type: "email",
              value: user.email,
              required: true,
              onChange: e => handleChangeRegister(e)
            }), emailfound && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
              className: "error-validacion",
              children: "Email ya existente"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Contrase\xF1a"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              id: "password",
              name: "password",
              type: "password",
              value: user.password,
              required: true,
              autoComplete: "on",
              onChange: e => handleChangeRegister(e)
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
              children: "Repetir Contrase\xF1a"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              id: "password2",
              name: "password2",
              type: "password",
              value: user.password2,
              required: true,
              autoComplete: "on",
              onChange: e => handleChangeRegister(e)
            }), invalidpassword && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
              className: "error-validacion",
              children: "Las contrase\xF1as deben ser iguales"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              type: "submit",
              value: "Enviar"
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(next_link__WEBPACK_IMPORTED_MODULE_4__["default"], {
              href: "/auth/company/register-company",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
                className: "profesional",
                children: "Me gustar\xEDa darme de alta como profesional"
              })
            })]
          })
        })]
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserRegister);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;