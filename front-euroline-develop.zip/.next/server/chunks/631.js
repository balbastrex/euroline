"use strict";
exports.id = 631;
exports.ids = [631];
exports.modules = {

/***/ 3631:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "tG": () => (/* binding */ getAllCategories),
/* harmony export */   "ax": () => (/* binding */ getCategoryById),
/* harmony export */   "V8": () => (/* binding */ getProductsByCategory),
/* harmony export */   "Dg": () => (/* binding */ getAllProducts),
/* harmony export */   "wv": () => (/* binding */ getProduct),
/* harmony export */   "kN": () => (/* binding */ getDesignGroupsById),
/* harmony export */   "ed": () => (/* binding */ getDesignByTag),
/* harmony export */   "KQ": () => (/* binding */ getPacks),
/* harmony export */   "Uz": () => (/* binding */ getPackByCategory),
/* harmony export */   "ko": () => (/* binding */ getPackById),
/* harmony export */   "cd": () => (/* binding */ getTopCategories),
/* harmony export */   "eU": () => (/* binding */ authLogin),
/* harmony export */   "N$": () => (/* binding */ userRegister),
/* harmony export */   "wd": () => (/* binding */ companyRegister),
/* harmony export */   "vS": () => (/* binding */ confirmRegisterEmail),
/* harmony export */   "Ay": () => (/* binding */ confirmCifCompany),
/* harmony export */   "yV": () => (/* binding */ getTokenCartNoAuth),
/* harmony export */   "gv": () => (/* binding */ getPublicCart),
/* harmony export */   "Re": () => (/* binding */ addLinesToCart),
/* harmony export */   "PI": () => (/* binding */ deleteCartLine),
/* harmony export */   "VQ": () => (/* binding */ getCustomerCart),
/* harmony export */   "nN": () => (/* binding */ addLinesToCustomerCart),
/* harmony export */   "mz": () => (/* binding */ deleteCustomerCartLine),
/* harmony export */   "ps": () => (/* binding */ getSearchProductByString)
/* harmony export */ });
/* unused harmony exports getTopDesigns, confirmCart */
/* harmony import */ var config_configAxios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4895);
/* harmony import */ var components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7504);

 // NOTE: All Categories

const getAllCategories = async () => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`categories`);
    return response.data.data.categories;
  } catch (error) {
    "There are an error getting Categories", error;
  }
}; // NOTE: Category By Id

const getCategoryById = async categoryId => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/categories/find/8`);
    return response.data;
  } catch (error) {
    "There are an error getting Categories", error;
  }
}; // NOTE: Products by Category

const getProductsByCategory = async categoryId => {
  if (categoryId) {
    try {
      const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`products/${categoryId}`);
      return response.data.data.products;
    } catch (error) {
      console.log("There are an error getting Products by Category", error);
    }
  }
}; // NOTE: All Products

const getAllProducts = async () => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products`);
    return response.data.data.products;
  } catch (error) {
    console.log("There are an error getting all Products", error);
  }
}; // NOTE: Product

const getProduct = async productId => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/find/${productId}`);
    return response.data.data.product;
  } catch (error) {
    console.log("There are an error getting Product", error);
  }
}; // NOTE: Design group by Design Id

const getDesignGroupsById = async designId => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/design-groups/find/${designId}`);
    response.data.data.design_group.designs.sort((a, b) => {
      return a.position - b.position;
    });
    return response.data.data.design_group.designs;
  } catch (error) {
    console.log("There are an error getting Design Group", error);
  }
}; // NOTE: Design group by Design

const getDesignByTag = async tagId => {
  if (tagId) {
    try {
      const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/products/designs-by-tag/${tagId}`);
      response.data.data.designs.sort((a, b) => {
        return a.position - b.position;
      });
      return response.data.data.designs;
    } catch (error) {
      console.log("There are an error getting Design by Tag", error);
    }
  }
}; // NOTE: All Packs

const getPacks = async () => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/packs`);
    response.data.data.packs.sort((a, b) => {
      return a.position - b.position;
    });
    return response.data.data.packs;
  } catch (error) {
    console.log("There are an error getting Packs", error);
  }
}; // NOTE: Packs by Category

const getPackByCategory = async categoryId => {
  if (categoryId) {
    try {
      const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/packs/${categoryId}`);
      if (!response.data.data.packs) return;
      response.data.data.packs.sort((a, b) => {
        return a.position - b.position;
      });
      return response.data.data.packs;
    } catch (error) {
      console.log("There are an error getting Packs by Category", error);
    }
  }
}; // NOTE: Pack by Id

const getPackById = async packId => {
  if (packId) {
    try {
      const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/packs/find/${packId}`);
      return response.data.data.pack;
    } catch (error) {
      console.log("There are an error getting Pack by Id", error);
    }
  }
}; // NOTE: Top Categories

const getTopCategories = async () => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/cms/top-categories`);
    return response.data.data.top_categories;
  } catch (error) {
    console.log("There are an error getting top_categories", error);
  }
}; // NOTE: Top Designs

const getTopDesigns = async () => {
  try {
    const response = await clienteAxios.get(`/cms/top-designs`);
    return response.data.data.top_designs;
  } catch (error) {
    console.log("There are an error getting top_categories", error);
  }
}; // NOTE: Login

const authLogin = async log => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/customers/login`, log);
    return response.data.data;
  } catch (error) {
    console.log(error);
  }
}; // NOTE: User Register

const userRegister = async user => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/customers/register-user`, user);
    return response.data.data;
  } catch (error) {
    console.log(error);
  }
}; // NOTE: Company Register

const companyRegister = async user => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/customers/register`, user);
    console.log(response);
    return response.data;
  } catch (error) {
    console.log(error);
    return error.response.data;
  }
}; // NOTE: Confirm User Email

const confirmRegisterEmail = async registerEmail => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/aaa/${registerEmail}/atr9ysu5afs5uasfg6fi8asyo9nua9gs`);
    return response.data.message;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Confirm Company CIF

const confirmCifCompany = async cifCompany => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/bbb/${cifCompany}/axg4ys15afs5u6atogg6fi8asyo9a9gf`);
    return response.data.message;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Get Cart if user or company is registered

const confirmCart = async () => {
  try {
    const response = await clienteAxios.get(`/shop/sales/carts`);
    return response;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Generate tokenCart if not autenticated

const getTokenCartNoAuth = async () => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/utils/generate-token/carts`);
    return response.data.data.token;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Get public Cart

const getPublicCart = async token => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/shop/sales/carts/${token}`);
    return response.data.data;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Add lines to public Cart

const addLinesToCart = async (linescart, token) => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/shop/sales/carts/lines/${token}`, linescart);
    return response;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Delete line to public Cart

const deleteCartLine = async (lineId, cartToken) => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/shop/sales/carts/lines/${lineId}/${cartToken}`);
    return response;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Get customer Cart

const getCustomerCart = async () => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/shop/sales/carts`);
    return response.data.data;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Add lines to customer Cart

const addLinesToCustomerCart = async linescart => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/shop/sales/carts/lines`, linescart);
    return response;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Delete line to customer Cart

const deleteCustomerCartLine = async lineId => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/shop/sales/carts/lines/${lineId}`);
    return response;
  } catch (error) {
    console.log(error);
  }
}; //NOTE: Search product by string (XIMO)

const getSearchProductByString = async str => {
  try {
    const response = await config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/shop/search/${str}`);
    return response;
  } catch (error) {
    console.log(error);
  }
};

/***/ }),

/***/ 7504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BV": () => (/* binding */ getTokenSession),
/* harmony export */   "y8": () => (/* binding */ initAxiosInterceptors),
/* harmony export */   "Ve": () => (/* binding */ setAnonymousCartToken),
/* harmony export */   "Xv": () => (/* binding */ getStoredAnonymousCartToken),
/* harmony export */   "uC": () => (/* binding */ detelteCartToken)
/* harmony export */ });
/* unused harmony exports setTokenSession, detelteTokenSession */
/* harmony import */ var _config_configAxios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4895);
 //SESSION TOKEN
//Almacenamos el token de sesión en localStorage con el nombre tokenSessionStorageClient

const setTokenSession = tokensession => {
  if (false) {}
}; //Obtenemos el token de sesión de localStorage

const getTokenSession = () => {
  if (false) {}
}; //Borramos el token de sesión

const detelteTokenSession = () => {
  if (false) {}
}; //Si hay token de sesión, lo incluimos en la cabecera de todas las llamadas a la Api

const initAxiosInterceptors = () => {
  _config_configAxios__WEBPACK_IMPORTED_MODULE_0__/* ["default"].interceptors.request.use */ .Z.interceptors.request.use(config => {
    const tokenSessionStorageClient = getTokenSession();

    if (tokenSessionStorageClient) {
      config.headers.Authorization = `Bearer ${tokenSessionStorageClient.replace(/[ '"]+/g, " ")}`;
    }

    return config;
  }, error => {
    return Promise.reject(error);
  });
}; //CART TOKEN
//Almacenamos el token de Carrito si no está logueado en localStorage con el nombre tokenSessionStorageClient

const setAnonymousCartToken = async cartToken => {
  try {
    if (false) {}
  } catch (error) {
    console.log(error);
  }
}; //Obtenemos el token de Carrito si no está logueado de localStorage

const getStoredAnonymousCartToken = async () => {
  try {
    if (false) {}
  } catch (error) {
    console.log(error);
  }
}; //Borramos el token de carrito

const detelteCartToken = () => {
  if (false) {}
};

/***/ }),

/***/ 4895:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const clienteAxios = axios__WEBPACK_IMPORTED_MODULE_0___default().create({
  baseURL: "https://ecomm.skydone.net/api/v1/acme12aa"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (clienteAxios);

/***/ })

};
;