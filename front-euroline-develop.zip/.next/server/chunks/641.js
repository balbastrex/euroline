exports.id = 641;
exports.ids = [641];
exports.modules = {

/***/ 4824:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_ui_GalleryProduct__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1770);
/* harmony import */ var context_cart_cartContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(491);
/* harmony import */ var components_detailPages_InfoCardDetail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1784);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_detailPages_InfoCardDetail__WEBPACK_IMPORTED_MODULE_3__]);
components_detailPages_InfoCardDetail__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const CardDetail = ({
  productDetail,
  packDetail,
  selectedProduct,
  designSelected
}) => {
  const cartContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context_cart_cartContext__WEBPACK_IMPORTED_MODULE_2__/* .CartContext */ .A);
  const {
    cart,
    setCart,
    cartlinepayload,
    setCartLinePayload,
    initialCartLinePayload
  } = cartContext;
  const {
    0: optionsId,
    1: setOptionsId
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: variation,
    1: setVariation
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: total,
    1: setTotal
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: subTotalPer,
    1: setSubTotalPer
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: extraPrice,
    1: setExtraPrice
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: discount,
    1: setDiscount
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
  const {
    0: personalization,
    1: setPersonalization
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: quantity,
    1: setQuantity
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  let variationSelected;
  let product;
  let initialOptions = {};

  if (selectedProduct) {
    product = selectedProduct;
  } else if (productDetail) {
    product = productDetail;
  }

  function array_equal(arr1, arr2) {
    if ((Array.isArray(arr1) && Array.isArray(arr2)) === false) return false;
    return JSON.stringify([...new Set(arr1.flat().sort())]) === JSON.stringify([...new Set(arr2.flat().sort())]);
  }

  if (product) {
    for (let i = 0; i < product.variations.length; i++) {
      if (array_equal(product.variations[i].option_ids, optionsId)) {
        variationSelected = product.variations[i];
      }
    }
  }

  let actionNoStock;

  if (variation && variation.emptyStockAction) {
    actionNoStock = variation.emptyStockAction.action;
  }

  const handleQuantity = e => {
    setQuantity(e.target.value);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("section", {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)("div", {
      id: "ficha-producto",
      className: "container",
      children: [(0,components_ui_GalleryProduct__WEBPACK_IMPORTED_MODULE_1__/* .GalleryProduct */ .H)(selectedProduct, designSelected, productDetail, packDetail), (0,components_detailPages_InfoCardDetail__WEBPACK_IMPORTED_MODULE_3__/* .InfoCardDetail */ .z)(product, extraPrice, variation, packDetail, discount, setDiscount, designSelected, personalization, setSubTotalPer, subTotalPer, setPersonalization, setExtraPrice, initialOptions, optionsId, setOptionsId, setVariation, variationSelected, setTotal, quantity, setQuantity, cartlinepayload, setCartLinePayload, cart, setCart, initialCartLinePayload), (0,components_detailPages_InfoCardDetail__WEBPACK_IMPORTED_MODULE_3__/* .Description */ .d)(variation, packDetail)]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardDetail);
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1784:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ InfoCardDetail),
/* harmony export */   "d": () => (/* binding */ Description)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_detailPages_Personalization__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5534);
/* harmony import */ var components_detailPages_Variations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5341);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5935);
/* harmony import */ var react_html_parser__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_html_parser__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7504);
/* harmony import */ var api_apiRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3631);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _packDetail_PackCustomization__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3403);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_6__]);
react_toastify__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













const InfoCardDetail = (product, extraPrice, variation, packDetail, discount, setDiscount, designSelected, personalization, setSubTotalPer, subTotalPer, setPersonalization, setExtraPrice, initialOptions, optionsId, setOptionsId, setVariation, variationSelected, setTotal, quantity, setQuantity, cartlinepayload, setCartLinePayload, cart, setCart, initialCartLinePayload) => {
  const {
    0: showpersonalization,
    1: setShowPersonalization
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  const {
    0: addlinecartactive,
    1: setAddLineCartActive
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: filterlinecartsotred,
    1: setFilterLineCartStored
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: showtoast,
    1: setShowToast
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (variation && variation.discount > 0 && variation.discount_type === "percentage") {
      setDiscount((Number(variation.price) * Number(variation.discount) / 100).toFixed(2));
    } else if (variation && variation.discount > 0 && variation.discount_type === "amount") {
      setDiscount(Number(variation.discount));
    } else if (variation && variation.discount === "0.0000") {
      setDiscount(Number(variation.discount));
    }

    if (Object.entries(personalization).length === 0 && !variation) {
      setShowPersonalization(false);
    }
  }, [setDiscount, variation, personalization]); //Comprobamos si tiene token de carrito sin estar logueado. Si no tiene, lo creamos y añadimos artículo

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (addlinecartactive) {
      const updateLinesCart = async () => {
        const sessionToken = (0,components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_4__/* .getTokenSession */ .BV)();

        if (!sessionToken) {
          const cartToken = await (0,components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_4__/* .getStoredAnonymousCartToken */ .Xv)();

          if (!cartToken) {
            const newCartToken = await (0,api_apiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .getTokenCartNoAuth */ .yV)();
            await (0,components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_4__/* .setAnonymousCartToken */ .Ve)(newCartToken);
            setAddLineCartActive(true);
            return;
          }

          const publicCart = await (0,api_apiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .addLinesToCart */ .Re)(cartlinepayload, cartToken);
          setCart(publicCart.data.data.cart);
          return;
        }

        const customerCart = await (0,api_apiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .addLinesToCustomerCart */ .nN)(cartlinepayload);
        setCart(customerCart.data.data.cart);
      };

      updateLinesCart();
    }

    setAddLineCartActive(false);
  }, [addlinecartactive, cartlinepayload]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    if (packDetail) {
      cartlinepayload.type = "pack";
      return;
    }

    cartlinepayload.type = "variation";
  }, []);

  const submitFormAddLineCart = async e => {
    e.preventDefault();
    await setCartLinePayload(_objectSpread(_objectSpread({}, cartlinepayload), {}, {
      design_id: designSelected && designSelected.id,
      design_customizations: filterlinecartsotred,
      id: variation ? variation.id : product ? product.variations[0].id : null,
      quantity: quantity,
      shop_option_ids: optionsId
    }));

    if (cartlinepayload.type === "pack") {
      setShowToast(true);
      react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.warn("👩‍💻 Pronto podrás añadir Packs a tu carrito", {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        className: "toast"
      });
      setTimeout(() => {
        setPersonalization({});
        e.target.reset();
        return;
      }, 1500);
    }

    if (cartlinepayload.type === "variation") {
      setShowToast(true);
      react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.success("🛒 ¡Añadido al carrito correctamente!", {
        position: "top-center",
        autoClose: 2000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
        progress: undefined,
        className: "toast"
      });
      setAddLineCartActive(true);
      setTimeout(() => {
        setPersonalization({});
        e.target.reset();
      }, 1500);
    }
  };

  const handlePlusQuantity = e => {
    e.preventDefault();
    setQuantity(quantity + 1);
  };

  const handleRestQuantity = e => {
    e.preventDefault();

    if (quantity === 1) {
      return;
    }

    setQuantity(quantity - 1);
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    id: "datos",
    children: [product && designSelected ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: [showtoast && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "titulo",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h5", {
          children: `${product.name} ${designSelected.name}`
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
          className: "referencia",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("small", {
              children: ["Ref: ", designSelected.ref]
            })
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "precio",
        children: [variation ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
          children: [Number(variation.price).toFixed(2), " \u20AC"]
        }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
          children: [Number(product.price).toFixed(2), " \u20AC"]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
          className: "iva-exc",
          children: "+ IVA"
        })]
      })]
    }) : variation && !designSelected ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: [showtoast && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "titulo",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h5", {
          children: `${variation.name} `
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
          className: "referencia",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("small", {
              children: ["Ref: ", variation.ref]
            })
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "precio",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
          children: [Number(variation.price).toFixed(2), " \u20AC"]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
          className: "iva-exc",
          children: "+ IVA"
        })]
      })]
    }) : packDetail && !variation && !designSelected ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: [showtoast && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {}), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "titulo",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h5", {
          children: `${packDetail.name} `
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
          className: "referencia",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("small", {
              children: ["Ref: ", packDetail.ref]
            })
          })
        })]
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        className: "precio",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("p", {
          children: [Number(packDetail.price).toFixed(2), " \u20AC"]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
          className: "iva-exc",
          children: "+ IVA"
        })]
      })]
    }) : null, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "personalizacion",
      children: [showpersonalization ? null : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h6", {
        children: "PERSONALIZACI\xD3N"
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
        id: "compra",
        onSubmit: e => submitFormAddLineCart(e),
        children: [(0,components_detailPages_Variations__WEBPACK_IMPORTED_MODULE_2__/* .Variations */ .b)(product, variation, packDetail, discount, subTotalPer, setExtraPrice, initialOptions, optionsId, setOptionsId, setVariation, variationSelected, setTotal, cartlinepayload, setCartLinePayload, cartlinepayload, setCartLinePayload), designSelected ? (0,components_detailPages_Personalization__WEBPACK_IMPORTED_MODULE_1__/* .Personalization */ .S)(extraPrice, designSelected, personalization, setSubTotalPer, subTotalPer, setPersonalization, setExtraPrice, setFilterLineCartStored) : null, variation && variation.stock === 0 && variation.emptyStockAction.action === "Visible sin venta" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "cantidades",
          disabled: true,
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
            children: "Cantidad"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: "input-group plus-minus-input",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
              className: "input-group-button",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("button", {
                disabled: true,
                type: "button",
                "data-quantity": "minus",
                "data-field": "quantity",
                className: "disabled",
                onClick: e => handleRestQuantity(e),
                children: "-"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              className: "cantidad",
              type: "number",
              name: "quantity",
              value: quantity = 0,
              readOnly: true
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
              className: "input-group-button",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("button", {
                disabled: true,
                type: "button",
                "data-quantity": "plus",
                "data-field": "quantity",
                onClick: e => handlePlusQuantity(e),
                children: "+"
              })
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
            disabled: true,
            type: "submit",
            value: "A\xF1adir al carrito"
          })]
        }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
          className: "cantidades",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("label", {
            children: "Cantidad"
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
            className: "input-group plus-minus-input",
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
              className: "input-group-button",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("button", {
                type: "button",
                "data-quantity": "minus",
                "data-field": "quantity",
                className: "disabled",
                onClick: e => handleRestQuantity(e),
                children: "-"
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
              className: "cantidad",
              type: "number",
              name: "quantity",
              value: quantity,
              readOnly: true
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
              className: "input-group-button",
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("button", {
                type: "button",
                "data-quantity": "plus",
                "data-field": "quantity",
                onClick: e => handlePlusQuantity(e),
                children: "+"
              })
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("input", {
            type: "submit",
            value: "A\xF1adir al carrito"
          })]
        })]
      })]
    })]
  });
};
const Description = (variation, packDetail) => {
  let packProducts;
  let productDescription;
  const {
    0: infoclass,
    1: setInfoClass
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: descriptionHtml,
    1: setDescriptionHtml
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
  const {
    0: productid,
    1: setProductId
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");

  const handleClass = () => {
    setInfoClass(!infoclass);
  };

  const infoProduct = async (productId, e) => {
    e.preventDefault();
    setProductId(productId);
    const valueToggleOpen = e.currentTarget.classList.toggle("open");
    setInfoClass(infoClass => !infoclass);

    if (valueToggleOpen === infoclass) {
      setInfoClass(true);
    }

    productDescription = packProducts.filter(product => product.id === productId);
    setDescriptionHtml(productDescription[0].variations[0].html);
  };

  if (packDetail) {
    packProducts = packDetail.products;
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
    children: variation ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
      children: variation.html ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
        id: "caracteristicas",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h6", {
          children: "Caracter\xEDsticas"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("ul", {
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("li", {
            children: variation.name
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h6", {
          children: "+ INFO"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
          className: !infoclass ? "componente-pack" : "componente-pack open",
          onClick: handleClass,
          children: variation.name
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
          className: "descripcion-componente",
          children: react_html_parser__WEBPACK_IMPORTED_MODULE_3___default()(variation.html)
        })]
      }) : null
    }) : packDetail ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      id: "caracteristicas",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h6", {
        children: "Caracter\xEDsticas"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("ul", {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("li", {
          children: packDetail.name
        })
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("br", {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("h6", {
        children: "+ INFO"
      }), packProducts.map(product => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: product.id !== productid ? product.variations && (product.variations[0].html === "<br>\n" || product.variations[0].html === null) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
          children: product.name
        }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
          className: "componente-pack",
          onClick: e => infoProduct(product.id, e),
          children: product.name
        }, product.id) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("a", {
            className: !infoclass ? "componente-pack" : infoclass ? "componente-pack open" : null,
            onClick: e => infoProduct(product.id, e),
            children: product.name
          }, product.id), infoclass && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
            className: "descripcion-componente",
            children: react_html_parser__WEBPACK_IMPORTED_MODULE_3___default()(descriptionHtml)
          })]
        })
      }, product.id))]
    }) : null
  });
};
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5534:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ Personalization)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const Personalization = (extraPrice, designSelected, personalization, setSubTotalPer, subTotalPer, setPersonalization, setExtraPrice, setFilterLineCartStored) => {
  const {
    0: error,
    1: setError
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: required,
    1: setRequired
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: linecartsotred,
    1: setLineCartStored
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: content,
    1: setContent
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: idcustomization,
    1: setIdCustomization
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: dataselectcustomization,
    1: setDataSelectCustomization
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const sumExtraPrice = () => {
      let subTotal = 0;

      if (Object.values(personalization)) {
        Object.keys(personalization).map(option => {
          designSelected.customizations.map(customization => {
            if (personalization[option].length >= customization.maxlength) {
              setError(true);
            }

            if ((personalization[option] === "" || personalization[option] === "0") && customization.label === option) {
              subTotal -= Number(customization.extra_price);
              setSubTotalPer(subTotal);
            }

            if (customization.label === option) {
              subTotal += Number(customization.extra_price);
              setSubTotalPer(subTotal);
            }
          });
        });
      }

      designSelected.customizations.map(custom => {
        if (custom.required === 1) {
          setRequired(true);
        }
      });
    };

    setError(false);
    sumExtraPrice();
  }, [designSelected.customizations, setSubTotalPer, personalization, setExtraPrice, extraPrice, subTotalPer]);

  const handlePersonalization = (e, customization) => {
    setPersonalization(_objectSpread(_objectSpread({}, personalization), {}, {
      [e.target.name]: e.target.value
    }));
    setContent(cont => e.target.value);
    setIdCustomization(customizationId => customization.id);
  };

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const AddItemsToCart = async () => {
      designSelected.customizations.map(customization => {
        //Comprobamos si hay select para extraer los datos,y adecuarlos en un [] e hidratar el selector
        if (customization && customization.input_type === "other") {
          const dataSelectCustomization = customization.default_content.split("|");
          setDataSelectCustomization(dataSelectCustomization);
        } //Si "key" === "label", almacenamos el id y content para pasarlo


        for (let key in personalization) {
          if (customization.label === key) {
            setLineCartStored([...linecartsotred, {
              id: idcustomization,
              content: content
            }]);
          }
        }
      });
    };

    AddItemsToCart();
  }, [designSelected.customizations, personalization, content]); //Filtramos los objetos introducidos con id y content, cogiendo el último elemento de la coincidencia con el metodo findLastIndex

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const filterResults = () => {
      let withoutRepeat = linecartsotred.filter((actualValue, index, storedArray) => index === storedArray.findLastIndex(t => t.id === actualValue.id));
      setFilterLineCartStored(line => withoutRepeat);
    };

    filterResults();
  }, [linecartsotred, setFilterLineCartStored]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: designSelected.customizations.length ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
      children: [designSelected.customizations.map(customization => {
        return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
          children: customization.input_type !== "other" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              id: customization.label,
              children: customization.extra_price !== "0.00" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                children: [customization.label, customization.required === 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
                  children: "*"
                }) : null, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("p", {
                  className: "leyenda",
                  children: [" ", "(Suplemento ", customization.extra_price, "\u20AC)"]
                })]
              }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                children: [customization.label, " ", customization.required === 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
                  children: "*"
                }) : null]
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
              "data-customization-id": customization.id,
              "data-design-id": customization.shop_design_id,
              name: customization.label,
              id: customization.id,
              type: customization.input_type,
              value: personalization.value,
              onChange: e => handlePersonalization(e, customization),
              maxLength: customization.maxlength,
              required: customization.required === 1 ? true : false,
              defaultValue: customization.input_type === "number" ? 0 : "",
              min: "0"
            }), customization.maxlength && error && customization.input_type === "text" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("p", {
              className: "error-validacion",
              children: ["M\xE1ximo ", customization.maxlength, " caracteres"]
            }) : null]
          }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("label", {
              id: customization.label,
              children: customization.extra_price !== "0.00" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                children: [customization.label, " ", customization.required === 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
                  children: "*"
                }) : null, /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("p", {
                  className: "leyenda",
                  children: ["(Suplemento ", customization.extra_price, "\u20AC)"]
                })]
              }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
                children: [customization.label, " ", customization.required === 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
                  children: "*"
                }) : null]
              })
            }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
              className: "select",
              children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("select", {
                "data-customization-id": customization.id,
                "data-design-id": customization.shop_design_id,
                required: customization.required === 1 ? true : false,
                name: customization.label,
                type: customization.input_type,
                value: customization.value,
                onChange: e => handlePersonalization(e, customization),
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
                  value: "",
                  children: "-- Elija mes --"
                }), dataselectcustomization && dataselectcustomization.map((month, i) => {
                  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
                    children: month
                  }, i);
                })]
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
                className: "icon",
                children: "keyboard_arrow_down"
              })]
            })]
          })
        }, customization.id);
      }), required ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
        className: "leyenda",
        children: "Campos con (*) son obligatorios"
      }) : null]
    }) : null
  });
};

/***/ }),

/***/ 5341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "b": () => (/* binding */ Variations)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/detailPages/packDetail/PackCustomization.js
var PackCustomization = __webpack_require__(3403);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/detailPages/packDetail/PackDesigns.js





const PackDesigns = ({
  packProduct
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
      children: packProduct.name
    }), packProduct.designs.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "select",
        children: [/*#__PURE__*/jsx_runtime_.jsx("select", {
          children: packProduct.designs.map((design, i) => /*#__PURE__*/jsx_runtime_.jsx("option", {
            children: design.name
          }, i))
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "icon",
          children: "keyboard_arrow_down"
        })]
      })
    }) : packProduct.designs.length === 1 ? /*#__PURE__*/jsx_runtime_.jsx("input", {
      readOnly: true,
      value: packProduct.designs[0].name
    }) : packProduct.designs.length === 0 ? /*#__PURE__*/jsx_runtime_.jsx("input", {
      readOnly: true,
      value: packProduct.name
    }) : null]
  });
};

/* harmony default export */ const packDetail_PackDesigns = (PackDesigns);
;// CONCATENATED MODULE: ./components/detailPages/packDetail/PackVariation.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const PackVariation = ({
  packProduct,
  handleChange,
  packoptionselect,
  setPackOptionSelect
}) => {
  (0,external_react_.useEffect)(() => {
    if (packProduct.optionGroups.length > 0) {
      {
        packProduct.optionGroups.map(option => {
          {
            option.options.length === 1 ? setPackOptionSelect(_objectSpread(_objectSpread({}, packoptionselect), {}, {
              [option.name]: option.options[0].name
            })) : null;
          }
        });
      }
    }
  }, [packProduct]);
  return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
    children: packProduct.optionGroups.length ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: packProduct.optionGroups.map(option => {
        if (option.options.length !== 1) {
          return /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              children: option.public_name
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "select",
              children: [/*#__PURE__*/jsx_runtime_.jsx("select", {
                name: option.name,
                onChange: e => handleChange(e),
                value: packoptionselect.value,
                children: option.options.map(opt => {
                  {
                    option.options.sort((a, b) => {
                      return a.position - b.position;
                    });
                  }
                  return /*#__PURE__*/jsx_runtime_.jsx("option", {
                    value: opt.name,
                    children: opt.name
                  }, opt.id);
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "icon",
                children: "keyboard_arrow_down"
              })]
            })]
          }, option.id);
        }
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: packProduct.optionGroups.map(option => {
        /*#__PURE__*/
        (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
          children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
            children: optGroup.public_name
          }, option.id), /*#__PURE__*/jsx_runtime_.jsx("input", {
            name: optGroup.key,
            value: optGroup.options[0].name,
            readOnly: true
          })]
        });
      })
    })
  });
};

/* harmony default export */ const packDetail_PackVariation = (PackVariation);
;// CONCATENATED MODULE: ./components/detailPages/packDetail/PackCard.js
function PackCard_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function PackCard_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { PackCard_ownKeys(Object(source), true).forEach(function (key) { PackCard_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { PackCard_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function PackCard_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }









const PackCard = ({
  packDetail
}) => {
  let packProducts = [];
  const {
    0: designsrc,
    1: setDesignsrc
  } = (0,external_react_.useState)("");
  const {
    0: radiodesign,
    1: setRadioDesign
  } = (0,external_react_.useState)([]);
  const {
    0: imgdesign,
    1: setImgDesign
  } = (0,external_react_.useState)({});
  const {
    0: productspackselected,
    1: setProductsPackSelected
  } = (0,external_react_.useState)({});
  const {
    0: packoptionselect,
    1: setPackOptionSelect
  } = (0,external_react_.useState)([]);
  const {
    0: showinfo,
    1: setShowInfo
  } = (0,external_react_.useState)(false);
  const {
    0: descriptionHtml,
    1: setDescriptionHtml
  } = (0,external_react_.useState)();
  const {
    0: productid,
    1: setProductId
  } = (0,external_react_.useState)("");
  const {
    0: quantity,
    1: setQuantity
  } = (0,external_react_.useState)(1);

  const handleChange = async e => {
    setPackOptionSelect(PackCard_objectSpread(PackCard_objectSpread({}, packoptionselect), {}, {
      [e.target.name]: e.target.value
    }));
  };

  if (packDetail) {
    packProducts = packDetail.products;
  } //NOTE: filtramos los elementos que hemos seleccionado previamente al último seleccionado para mantener la imágen del diseño y no cambie al seleccionar otro nuevamente


  const keepImgDesign = radiodesign.filter(element => element.design.shop_design_group_id !== imgdesign.shop_design_group_id);
  let otherDesignSelected;

  for (let i = 0; i < keepImgDesign.length; i++) {
    otherDesignSelected = keepImgDesign[i];
  } ///


  let productDescription;
  /*   let descriptionHtml; */

  const infoProduct = async productId => {
    setProductId(productId);
    setShowInfo(true);
    productDescription = packProducts.filter(product => product.id === productId);
    setDescriptionHtml(productDescription[0].variations[0].html);
  };

  const handleQuantity = e => {
    setQuantity(e.target.value);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [packProducts.map(packProduct => /*#__PURE__*/(0,jsx_runtime_.jsxs)(external_react_.Fragment, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(packDetail_PackDesigns, {
        packProduct: packProduct
      }), /*#__PURE__*/jsx_runtime_.jsx(packDetail_PackVariation, {
        packProduct: packProduct,
        handleChange: handleChange,
        packoptionselect: packoptionselect,
        setPackOptionSelect: setPackOptionSelect
      })]
    }, packProduct.id)), /*#__PURE__*/jsx_runtime_.jsx(PackCustomization/* default */.Z, {
      packDetail: packDetail,
      packProducts: packProducts,
      designsrc: designsrc
    })]
  });
};

/* harmony default export */ const packDetail_PackCard = (PackCard);
;// CONCATENATED MODULE: ./components/detailPages/Variations.js
function Variations_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Variations_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Variations_ownKeys(Object(source), true).forEach(function (key) { Variations_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Variations_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Variations_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Variations = (product, variation, packDetail, discount, subTotalPer, setExtraPrice, initialOptions, optionsId, setOptionsId, setVariation, variationSelected, setTotal, cartproduct, setCartProduct, cartlinepayload, setCartLinePayload) => {
  const {
    0: optionSelect,
    1: setOptionSelect
  } = (0,external_react_.useState)({});
  let initialOptionsId = [];
  let subTotalOpt = 0;
  let correctPrice;

  if (product) {
    correctPrice = product.price;
  }

  if (product && product.variations[0]) {
    correctPrice = product.variations[0].price;
  }

  if (variation) {
    correctPrice = variation.price;
  }

  if (packDetail) {
    correctPrice = packDetail.price;
  }

  const handleChange = async e => {
    setOptionSelect(Variations_objectSpread(Variations_objectSpread({}, optionSelect), {}, {
      [e.target.name]: Number(e.target.value)
    }));
    setOptionsId(Object.values(optionSelect));
  };

  (0,external_react_.useEffect)(() => {
    if (product && product.variations.length || packDetail) {
      setTotal(Number(correctPrice) + Number(subTotalOpt) + Number(subTotalPer) - Number(discount));
      setExtraPrice(subTotalOpt + subTotalPer);
      setVariation(variationSelected);
      setOptionsId(Object.values(optionSelect));
    }

    if (product && product.optionGroups) {
      if (!optionsId.length) {
        setOptionSelect(initialOptions);
        setOptionsId(initialOptionsId);
      }

      const variationChange = () => {
        setTotal(Number(correctPrice) + Number(subTotalOpt) + Number(subTotalPer) - Number(discount));
        setExtraPrice(subTotalOpt + subTotalPer);
        setVariation(variationSelected);
        setOptionsId(Object.values(optionSelect));
      };

      variationChange();
    } // eslint-disable-next-line react-hooks/exhaustive-deps

  }, [variationSelected, optionSelect, correctPrice, subTotalPer, discount]);
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: product && product.optionGroups ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [product.optionGroups.map(optGroup => {
        initialOptionsId.push(optGroup.options[0].id);
        initialOptions = Variations_objectSpread(Variations_objectSpread({}, initialOptions), {}, {
          [optGroup.key]: optGroup.options[0].id
        });
        subTotalOpt = Number(optGroup.options[0].extra_price);
        return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
          children: optGroup.options.length !== 1 ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              children: optGroup.public_name
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "select",
              children: [/*#__PURE__*/jsx_runtime_.jsx("select", {
                name: optGroup.key,
                onChange: e => handleChange(e),
                value: optionSelect.value,
                children: optGroup.options.map(opt => {
                  {
                    optGroup.options.sort((a, b) => {
                      return b.position - a.position;
                    });
                  }
                  return /*#__PURE__*/jsx_runtime_.jsx("option", {
                    value: opt.id,
                    children: opt.name
                  }, opt.id);
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                className: "icon",
                children: "keyboard_arrow_down"
              })]
            })]
          }) : /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              children: optGroup.public_name
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              name: optGroup.key,
              value: optGroup.options[0].name,
              readOnly: true
            })]
          })
        }, optGroup.id);
      }), variation && /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: variation.stock === 0 ? /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "aviso-stock",
          children: variation.emptyStockAction.message
        }) : null
      })]
    }) : packDetail ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/jsx_runtime_.jsx(packDetail_PackCard, {
        packDetail: packDetail
      })
    }) : null
  });
};

/***/ }),

/***/ 3403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


/* import styles from "styles/CardDetail.module.css"; */





const PackCustomization = ({
  packProducts
}) => {
  const {
    0: error,
    1: setError
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: personalization,
    1: setPersonalization
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: required,
    1: setRequired
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  /*   const [products, setProducts] = useState([]); */

  let allCustomizations = [];
  const months = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
  let customsMapArr;
  let filterCustomizations; ///Filtrar Personalizaciones
  ///Metemos todas las personalizaciones en allCustomizations

  packProducts.map(product => product.designs.map(design => design.customizations.map(custom => allCustomizations.push(custom)))); ///Eliminamos las personalizaciones repetidas

  const allCustom = allCustomizations.map(custom => {
    return [custom.label, custom];
  });
  customsMapArr = new Map(allCustom);
  filterCustomizations = [...customsMapArr.values()]; ///

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const packsCustomization = () => {
      if (Object.values(personalization)) {
        Object.keys(personalization).map(option => filterCustomizations.map(customization => {
          if (personalization[option].length >= customization.maxlength) {
            setError(true);
          }

          if (customization.required === 1) {
            setRequired(true);
          }
        }));
      }

      filterCustomizations.map(customization => {
        if (customization.required === 1) {
          setRequired(true);
        }
      });
    };

    setError(false);
    packsCustomization();
  }, [customsMapArr, filterCustomizations, personalization]);

  const handlePersonalization = e => {
    setPersonalization(_objectSpread(_objectSpread({}, personalization), {}, {
      [e.target.name]: e.target.value
    }));
  };

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: [filterCustomizations.map(customization => {
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: customization.input_type !== "other" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("label", {
            children: [customization.required === 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
              children: "*"
            }) : null, /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
              children: customization.label
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("input", {
            name: customization.label,
            type: customization.input_type,
            value: personalization.value,
            onChange: e => handlePersonalization(e),
            maxLength: customization.maxlength,
            required: customization.required === 1 ? true : false,
            defaultValue: customization.input_type === "number" ? 0 : "",
            min: "0"
          }), customization.maxlength && error && customization.input_type === "text" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("p", {
            className: "error-validacion",
            children: ["M\xE1ximo ", customization.maxlength, " caracteres"]
          }) : null]
        }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("label", {
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
              children: customization.label
            }), customization.required === 1 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
              children: "*"
            }) : null, " "]
          }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("select", {
            required: customization.required === 1 ? true : false,
            name: customization.label,
            type: customization.input_type,
            value: customization.value,
            onChange: e => handlePersonalization(e),
            children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
              value: "",
              children: "-- Elija mes --"
            }), months.map((month, i) => {
              return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("option", {
                children: month
              }, i);
            })]
          })]
        })
      }, customization.id);
    }), required ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("p", {
      className: "aviso-validacion",
      children: "Campos con (*) son obligatorios"
    }) : null]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PackCustomization);

/***/ }),

/***/ 1770:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ GalleryProduct)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);




const GalleryProduct = (selectedProduct, designSelected, productDetail, packDetail) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    id: "imagenes",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
      className: "etiqueta nuevo",
      children: "Nuevo"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
      className: "galeria",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: "fotos-producto",
        children: designSelected && selectedProduct.images ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: [designSelected.src && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
            id: designSelected.id,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${designSelected.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${designSelected.src}`,
                alt: designSelected.alt
              })]
            })
          }, designSelected.id), selectedProduct.images.map((picture, i) => {
            return selectedProduct.images.sort((a, b) => a.position - b.position), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
              id: `foto-${picture.id}-${i++}-${i}`,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                  srcSet: `https://ecomm.skydone.net${picture.src}`,
                  type: "image/webp"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                  src: `https://ecomm.skydone.net${picture.src}`,
                  alt: picture.alt
                })]
              })
            }, picture.id);
          }), designSelected && designSelected.typography && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
            id: "typography",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${designSelected.typography.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${designSelected.typography.src}`,
                alt: designSelected.typography.alt
              })]
            })
          }, designSelected.typography.id)]
        }) :
        /* Productos */
        productDetail && productDetail.images ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: productDetail.images.map((picture, i) => {
            return productDetail.images.sort((a, b) => a.position - b.position), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
              id: `foto-${picture.id}-${i++}-${i}`,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                  srcSet: `https://ecomm.skydone.net${picture.src}`,
                  type: "image/webp"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                  src: `https://ecomm.skydone.net${picture.src}`,
                  alt: picture.alt
                })]
              })
            }, picture.id);
          })
        }) :
        /* Packs */
        packDetail ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: [packDetail.images && packDetail.images && packDetail.images.map((image, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
            id: `foto-${image.id}-${i}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${image.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${image.src}`,
                alt: image.alt
              })]
            })
          }, image.src)), packDetail.products && packDetail.products.length >= 1 && packDetail.products.map((packProduct, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
            id: `foto-${packProduct.id}-${i++}-${i}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${packProduct.main_image.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${packProduct.main_image.src}`,
                alt: packProduct.main_image.alt
              })]
            })
          }, packProduct.id)), packDetail.products && packDetail.products.length >= 1 && packDetail.products.map(packProduct => packProduct.designs && packProduct.designs.length >= 1 && packProduct.designs.map((designImage, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
            id: `foto-${designImage.id}-${i++}-${i}-${i}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${designImage.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${designImage.src}`,
                alt: designImage.alt
              })]
            })
          }, designImage.id)))]
        }) : null
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
        className: "miniaturas-producto",
        children:
        /* Diseños */
        designSelected && selectedProduct.images ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: [designSelected.src && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            href: `#${designSelected.id}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${designSelected.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${designSelected.src}`,
                alt: designSelected.alt
              })]
            })
          }, designSelected.id), selectedProduct.images.map((picture, i) => {
            return selectedProduct.images.sort((a, b) => a.position - b.position), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
              href: `#foto-${picture.id}-${i++}-${i}`,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                  srcSet: `https://ecomm.skydone.net${picture.src}`,
                  type: "image/webp"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                  src: `https://ecomm.skydone.net${picture.src}`,
                  alt: picture.alt
                })]
              })
            }, picture.id);
          }), designSelected && designSelected.typography && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            href: "#typography",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${designSelected.typography.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${designSelected.typography.src}`,
                alt: designSelected.typography.alt
              })]
            })
          }, designSelected.typography.id)]
        }) :
        /* Productos */
        productDetail && productDetail.images ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: productDetail.images.map((picture, i) => {
            return productDetail.images.sort((a, b) => a.position - b.position), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
              href: `#foto-${picture.id}-${i++}-${i}`,
              children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
                children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                  srcSet: `https://ecomm.skydone.net${picture.src}`,
                  type: "image/webp"
                }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                  src: `https://ecomm.skydone.net${picture.src}`,
                  alt: picture.alt
                })]
              })
            }, picture.id);
          })
        }) :
        /* Packs */
        packDetail ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
          children: [packDetail.images && packDetail.images.length && packDetail.images.map((image, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            href: `#foto-${image.id}-${i}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${image.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${image.src}`,
                alt: image.alt
              })]
            })
          }, image.src)), packDetail.products && packDetail.products.length >= 1 && packDetail.products.map((packProduct, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            href: `#foto-${packProduct.id}-${i++}-${i}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${packProduct.main_image.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${packProduct.main_image.src}`,
                alt: packProduct.main_image.alt
              })]
            })
          }, packProduct.id)), packDetail.products && packDetail.products.length >= 1 && packDetail.products.map(packProduct => packProduct.designs && packProduct.designs.length >= 1 && packProduct.designs.map((designImage, i) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("a", {
            href: `#foto-${designImage.id}-${i++}-${i}-${i}`,
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("source", {
                srcSet: `https://ecomm.skydone.net${designImage.src}`,
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("img", {
                src: `https://ecomm.skydone.net${designImage.src}`,
                alt: designImage.alt
              })]
            })
          }, designImage.id)))]
        }) : null
      })]
    })]
  });
};

/***/ }),

/***/ 2780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5976);
/* harmony import */ var styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const Spinner = () => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: (styles_ui_Spinner_module_css__WEBPACK_IMPORTED_MODULE_1___default().loader),
    children: "Loading..."
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Spinner);

/***/ }),

/***/ 5976:
/***/ ((module) => {

// Exports
module.exports = {
	"loader": "Spinner_loader__U4LJD",
	"load5": "Spinner_load5__s2jZt"
};


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;