"use strict";
exports.id = 468;
exports.ids = [468];
exports.modules = {

/***/ 7468:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ DesignCard)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);





const DesignCard = (x, selectedProduct, designSelected, productDetail, packDetail) => {
  let design;
  let designSel;

  if (selectedProduct) {
    design = designSelected;
  } else if (productDetail) {
    design = productDetail;
  } else if (packDetail) {
    design = packDetail;
  } else if (x) {
    design = x;
  }

  if (designSelected) {
    designSel = selectedProduct;
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: x && !packDetail && !selectedProduct && !designSelected && !productDetail ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
      className: "producto",
      children: design.canonical_uri ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
          href: {
            pathname: "/shop/[productDetail]",
            query: {
              productDetail: design.canonical_uri.replace(/[/]/g, "_")
            }
          },
          passHref: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
            className: "imagen",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("source", {
                src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
                src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
                alt: design.main_image && design.main_image.alt !== "" ? design.main_image.alt : `${design.name} image`
              })]
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
          href: {
            pathname: "/shop/[productDetail]",
            query: {
              productDetail: design.canonical_uri.replace(/[/]/g, "_")
            }
          },
          passHref: true,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("a", {
            className: "nombre",
            children: [design.products && design.products[0].name, " ", design.name]
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: "precio",
          children: [design.variation && design.variation.price ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
            children: [" ", Number(design.variation.price).toFixed(2), " \u20AC"]
          }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
            children: [" ", Number(design.price).toFixed(2), " \u20AC"]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
            className: "iva-exc",
            children: "+ IVA"
          })]
        })]
      }) : design.products ?
      /*#__PURE__*/

      /*Ficha de Diseños */
      (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
          href: {
            pathname: "/shop/[productDetail]/[designDetail]",
            query: {
              productDetail: design.products[0].slug,
              designDetail: design.slug
            }
          },
          passHref: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
            className: "imagen",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("source", {
                src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
                src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
                alt: design.main_image && design.main_image.alt !== "" ? design.main_image.alt : `${design.name} image`
              })]
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
          href: {
            pathname: "/shop/[productDetail]/[designDetail]",
            query: {
              designDetail: design.slug,
              productDetail: design.products[0].slug
            }
          },
          passHref: true,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("a", {
            className: "nombre",
            children: [design.products && design.products[0].name, " ", design.name]
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: "precio",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
            children: [Number(design.products[0].variation.price).toFixed(2), " \u20AC"]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
            className: "iva-exc",
            children: "+ IVA"
          })]
        })]
      }) :
      /*#__PURE__*/

      /*Ficha de Designs */
      (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
          href: {
            pathname: "/shop/[productDetail]/[designDetail]",
            query: {
              productDetail: design.productSlug,
              designDetail: design.slug
            }
          },
          passHref: true,
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
            className: "imagen",
            children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("picture", {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("source", {
                src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
                type: "image/webp"
              }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
                src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
                alt: design.main_image && design.main_image.alt !== "" ? design.main_image.alt : `${design.name} image`
              })]
            })
          })
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
          href: {
            pathname: "/shop/[productDetail]/[designDetail]",
            query: {
              designDetail: design.slug,
              productDetail: design.productSlug
            }
          },
          passHref: true,
          children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("a", {
            className: "nombre",
            children: [design.productName, " ", design.name]
          })
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
          className: "precio",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("p", {
            children: [Number(design.price).toFixed(2), " \u20AC"]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("span", {
            className: "iva-exc",
            children: "+ IVA"
          })]
        })]
      })
    }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("div", {
      children: [design && design.productName ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("h3", {
        children: [design.productName, " ", design.name]
      }) : packDetail ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h3", {
        children: packDetail.name
      }) : design && !design.productName && !designSel ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("h3", {
        children: [design.products && design.products[0].name, " ", design.name]
      }) : design && !design.productName && designSel ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("h3", {
        children: [designSel.name, " ", design.name]
      }) : designSel ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("h3", {
        children: [designSel.name, " ", design.name]
      }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("h3", {
        children: design.name
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsxs)("picture", {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("source", {
          src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
          type: "image/webp"
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
          src: !design.main_image && !design.src && (!design.images || !design.images[0].src) ? "/mi_pipo.jpg" : design.main_image ? `${"https://ecomm.skydone.net"}${design.main_image.src}` : design.src ? `${"https://ecomm.skydone.net"}${design.src}` : design.images[0].src ? `${"https://ecomm.skydone.net"}${design.images[0].src}` : "/mi_pipo.jpg",
          alt: design.main_image && design.main_image.alt !== "" ? design.main_image.alt : `${design.name} image`
        })]
      })]
    })
  });
};

/***/ })

};
;