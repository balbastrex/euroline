"use strict";
exports.id = 274;
exports.ids = [274];
exports.modules = {

/***/ 491:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ CartContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7504);
/* harmony import */ var context_user_userContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8753);
/* harmony import */ var api_apiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3631);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);





const CartContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();

const CartProvider = props => {
  const {
    tokensession,
    initialLogin
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context_user_userContext__WEBPACK_IMPORTED_MODULE_2__/* .UserContext */ .S);
  const {
    0: cart,
    1: setCart
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: tokenCart,
    1: setTokenCart
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const initialCartLinePayload = {
    design_id: null,
    design_customizations: [{
      id: "",
      content: ""
    }, {
      id: "",
      content: ""
    }],
    id: "",
    quantity: "",
    type: "",
    shop_option_ids: []
  };
  const {
    0: cartlinepayload,
    1: setCartLinePayload
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialCartLinePayload);
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    const storedTokenCart = async () => {
      const tokenStored = await (0,components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_1__/* .getStoredAnonymousCartToken */ .Xv)();

      if (tokenStored) {
        setTokenCart(() => tokenStored);
      }
    };

    storedTokenCart();
  }, [cart, tokenCart]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(CartContext.Provider, {
    value: {
      cart,
      cartlinepayload,
      tokenCart,
      initialCartLinePayload,
      setTokenCart,
      setCartLinePayload,
      setCart
    },
    children: props.children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartProvider);

/***/ }),

/***/ 9235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* binding */ CategoriesContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const CategoriesContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();

const CategoriesProvider = props => {
  //OK: categoriesSorted, categories ordered by position, ready for menu [5]
  const {
    0: categoriesSorted,
    1: setCategoriesSorted
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]); //OK: categories, All categories ordered by position with subCategories [12]

  const {
    0: categories,
    1: setCategories
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]); //OK: selectedCategory, Category Selected with subCategories in menu or Categories componet Link {1}

  const {
    0: selectedCategory,
    1: setSelectedCategory
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({}); //OK: loadSpinner, State to show Spinner component or not

  const {
    0: loadSpinner,
    1: setLoadSpinner
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);

  const getCategoriesSorted = async () => {
    setCategoriesSorted(categories[0].subCategory);
  }; //Almacenamos en el contexto las categorias por niveles añadiendo sus subcategorias


  let newObject = {};
  categories.forEach(category => {
    if (!newObject.hasOwnProperty(category.level)) {
      newObject[category.level] = _objectSpread({}, category);
    }
  });
  let categoryCopy = [...categories],
      categoryCompare = [...categories];
  categoryCompare.forEach(category => {
    category.subCategory = [];
    categoryCopy.forEach(copyElement => {
      if (copyElement.parent_id === category.id) {
        category.subCategory.push(copyElement);
      }
    });
  }); ////
  //Ordenamos el menú por posición de las categorias

  const menuOrder = categories => {
    return categories.map(category => {
      categories.sort((a, b) => {
        return a.position - b.position;
      });

      if (category.subCategory.length) {
        menuOrder(category.subCategory);
      }
    });
  };

  menuOrder(categories); ////

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(CategoriesContext.Provider, {
    value: {
      categories,
      selectedCategory,
      categoriesSorted,
      loadSpinner,
      setCategories,
      setSelectedCategory,
      setCategoriesSorted,
      setLoadSpinner,

      /* getAllCategories, */
      getCategoriesSorted
    },
    children: props.children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoriesProvider);

/***/ }),

/***/ 8753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ UserContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_auth_authHelpers__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7504);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);



const UserContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();

const UserProvider = props => {
  const initialCompany = {
    _method: "POST",
    name: "",
    email: "",
    password: "",
    password2: "",
    phone: "",
    phone_2: "",
    DNI: "",
    tradename: "",
    companyname: "",
    CIF: "",
    re: 1,
    iva: 1,
    address: "",
    city: "",
    postcode: "",
    clone_as_delivery_address: 0,
    address_name: "",
    customer_groups: [],
    subscriptions: [],
    contact_name: "",
    add_company: 1,
    register_company: 1,
    company_types: [],
    region_id: "",
    country_id: ""
  };
  const initialUser = {
    name: "",
    email: "",
    password: "",
    password2: ""
  };
  const {
    0: tokenstored,
    1: setTokenStored
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const initialLogin = {
    email: "",
    password: "",
    token: ""
  };
  const {
    0: company,
    1: setCompany
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialCompany);
  const {
    0: user,
    1: setUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialUser);
  const {
    0: login,
    1: setLogin
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialLogin);
  const {
    0: tokensession,
    1: setTokenSession
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(UserContext.Provider, {
    value: {
      initialCompany,
      initialUser,
      initialLogin,
      user,
      login,
      company,
      tokensession,
      tokenstored,
      setTokenStored,
      setUser,
      setLogin,
      setCompany,
      setTokenSession
    },
    children: props.children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserProvider);

/***/ })

};
;