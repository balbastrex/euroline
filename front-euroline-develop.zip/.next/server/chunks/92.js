"use strict";
exports.id = 92;
exports.ids = [92];
exports.modules = {

/***/ 4092:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ DesignsContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var context_categories_categoriesContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9235);
/* harmony import */ var _api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3631);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);




const DesignsContext = /*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)();

const DesignsProvider = props => {
  const categoriesContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context_categories_categoriesContext__WEBPACK_IMPORTED_MODULE_1__/* .CategoriesContext */ .i);
  const {
    loadSpinner,
    setLoadSpinner
  } = categoriesContext;
  const {
    0: allDesigns,
    1: setAllDesigns
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
  const {
    0: stopGetDesigns,
    1: setStopGetDesigns
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: productByCategory,
    1: setProductByCategory
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);

  const getDesigns = async productsByCategorySelected => {
    let data = [];
    let productSlug = "";
    let productName = "";
    let allDesignsGroup;
    let allDesignsGroupCopy;
    setAllDesigns([]);
    setProductByCategory(productsByCategorySelected);
    /* setStopGetDesigns(true); */

    if (productByCategory === productsByCategorySelected && productByCategory) {
      //NOTE: No tocar, Spinner mientras cargan los diseños
      setLoadSpinner(false);

      for (let i = 0; i < productByCategory.length; i++) {
        try {
          if (productByCategory[i].shop_design_group_id !== null) {
            const designId = await productByCategory[i].shop_design_group_id;
            const designsGroupId = await (0,_api_apiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .getDesignGroupsById */ .kN)(designId);
            allDesignsGroupCopy = await designsGroupId;
            productSlug = await productByCategory[i].slug;
            productName = await productByCategory[i].name; //NOTE: filtrar los repetidos y meterlos en data

            if (designsGroupId !== undefined) {
              designsGroupId.map(design => {
                design.productSlug = productSlug || "";
                design.productName = productName || "";
                allDesignsGroupCopy.map(designCopy => {
                  if (design.id === designCopy.id && !data.includes(designCopy.id)) {
                    data.push(designCopy);
                  }
                });
              });
            }
          } else {
            data.push(productByCategory[i]);
          }
        } catch (error) {
          console.log("There are an error", error);
        }
      }

      setAllDesigns(data);
      setLoadSpinner(true);
    }

    setLoadSpinner(false);
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(DesignsContext.Provider, {
    value: {
      allDesigns,
      stopGetDesigns,
      productByCategory,
      loadSpinner,
      setLoadSpinner,
      setProductByCategory,
      setStopGetDesigns,
      setAllDesigns,
      getDesigns
    },
    children: props.children
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DesignsProvider);

/***/ })

};
;