import React from "react";
import Layout from "components/layout/Layout";
import Producto from "components/prueba/producto";

function Home() {
  return (
    <Layout page="Tienda Tuning">
      <div className="container">
        <div>
          <Producto />
        </div>
      </div>
    </Layout>
  );
}

export default Home;
