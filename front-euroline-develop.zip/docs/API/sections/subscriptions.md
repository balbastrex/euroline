# Subscriptions

> Subcription types

    # Public
    GET | {domain}/api/v1/{shopKey}/subscriptions/types/{lang?}

Examples:

    http://skyerp.local/api/v1/acme12aa/subscriptions/types


***

[API]("../../../API.md)
|
[Go to index]("../../../../README.md)
