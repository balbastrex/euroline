import Link from "next/link";
import React from "react";

function ResultBox(params) {
  return (
    <Link href="#">
      <a>
        <div>
          <picture>
            <img src={"https://picsum.photos/200"} type="image/webp" alt="" />
          </picture>
        </div>
        <div>
          <p>{params.name}</p>
          <p>650€</p>
        </div>
      </a>
    </Link>
  );
}

export default ResultBox;
